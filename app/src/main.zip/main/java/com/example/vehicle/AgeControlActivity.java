package com.example.vehicle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class AgeControlActivity extends AppCompatActivity {
    private Button btnAdultUser, btnChildUser;
    public void init(){
        btnAdultUser = (Button) findViewById(R.id.btnAdultUser);
        btnChildUser = (Button) findViewById(R.id.btnChildUser);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agecontrol);
        init();

        btnAdultUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentAdultUser = new Intent(AgeControlActivity.this, RegisterActivity.class);
                startActivity(intentAdultUser);
            }
        });

        btnChildUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentChildUser = new Intent(AgeControlActivity.this, RegisterActivity.class);
                startActivity(intentChildUser);
            }
        });
    }

}







