package com.example.vehicle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class AdultActivitiesActivity extends AppCompatActivity {
    public Toolbar actionbarLoad_credit;
    public Toolbar actionbarCreate_child_account;
    public Toolbar actionbarTracking_child;

    public Button btnLoadCredit;
    public Button btnCreateChildAccount;
    public Button btnTrackingChild;

    public void init(){
        actionbarLoad_credit = (Toolbar) findViewById(R.id.actionbarLoad_credit);
        setSupportActionBar(actionbarLoad_credit);
        getSupportActionBar().setTitle("Load Credit");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        actionbarCreate_child_account = (Toolbar) findViewById(R.id.actionbarReport_broken_vehicle);
        setSupportActionBar(actionbarCreate_child_account);
        getSupportActionBar().setTitle("Report Broken Vehicle");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        actionbarTracking_child = (Toolbar) findViewById(R.id.actionbarDisplay_gift_coupon);
        setSupportActionBar(actionbarTracking_child);
        getSupportActionBar().setTitle("Display Gift Coupon");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        btnLoadCredit = (Button) findViewById(R.id.btnLoadCredit);
        btnCreateChildAccount = (Button) findViewById(R.id.btnCreateChildAccount);
        btnTrackingChild = (Button) findViewById(R.id.btnTrackingChild);

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adultactivities);
        init();

        btnLoadCredit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentLoadCredit = new Intent(AdultActivitiesActivity.this, AdultMainMenuActivity.class);
                startActivity(intentLoadCredit);
                finish();
            }
        });

        btnCreateChildAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentCreateChildAccount = new Intent(AdultActivitiesActivity.this, AdultMainMenuActivity.class);
                startActivity(intentCreateChildAccount);
                finish();
            }
        });

        btnTrackingChild.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentTrackingChild = new Intent(AdultActivitiesActivity.this, AdultMainMenuActivity.class);
                startActivity(intentTrackingChild);
                finish();
            }
        });
    }
}