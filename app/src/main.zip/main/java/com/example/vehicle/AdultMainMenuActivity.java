package com.example.vehicle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class AdultMainMenuActivity extends AppCompatActivity {
    public Toolbar actionbarRenta_vehicle;
    public Toolbar actionbarBooka_vehicle;
    public Toolbar actionbarDisplay_my_rides;
    public Toolbar actionbarReport_broken_vehicle;
    public Toolbar actionbarDisplay_gift_coupon;
    public Toolbar actionbarAdult_activities;

    public Button btnRentaVehicle;
    public Button btnBookaVehicle;
    public Button btnDisplayMyRides;
    public Button btnReportBrokenVehicle;
    public Button btnDisplayGiftCoupon;
    public Button btnAdultActivities;

    public void init(){
        actionbarRenta_vehicle = (Toolbar) findViewById(R.id.actionbarRenta_vehicle);
        setSupportActionBar(actionbarRenta_vehicle);
        getSupportActionBar().setTitle("Rent a Vehicle");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        actionbarBooka_vehicle = (Toolbar) findViewById(R.id.actionbarBooka_vehicle);
        setSupportActionBar(actionbarBooka_vehicle);
        getSupportActionBar().setTitle("Book a Vehicle");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        actionbarDisplay_my_rides = (Toolbar) findViewById(R.id.actionbarDisplay_my_rides);
        setSupportActionBar(actionbarDisplay_my_rides);
        getSupportActionBar().setTitle("Display My Rides");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        actionbarReport_broken_vehicle = (Toolbar) findViewById(R.id.actionbarReport_broken_vehicle);
        setSupportActionBar(actionbarReport_broken_vehicle);
        getSupportActionBar().setTitle("Report Broken Vehicle");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        actionbarDisplay_gift_coupon = (Toolbar) findViewById(R.id.actionbarDisplay_gift_coupon);
        setSupportActionBar(actionbarDisplay_gift_coupon);
        getSupportActionBar().setTitle("Display Gift Coupon");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        actionbarAdult_activities = (Toolbar) findViewById(R.id.actionbarAdult_activities);
        setSupportActionBar(actionbarAdult_activities);
        getSupportActionBar().setTitle("Adult Activities");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        btnRentaVehicle = (Button) findViewById(R.id.btnRentaVehicle);
        btnBookaVehicle = (Button) findViewById(R.id.btnBookaVehicle);
        btnDisplayMyRides = (Button) findViewById(R.id.btnDisplayMyRides);
        btnReportBrokenVehicle = (Button) findViewById(R.id.btnReportBrokenVehicle);
        btnDisplayGiftCoupon = (Button) findViewById(R.id.btnDisplayGiftCoupon);
        btnAdultActivities = (Button) findViewById(R.id.btnAdultActivities);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adultmainmenu);
        init();

        btnRentaVehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentRent = new Intent(AdultMainMenuActivity.this, AdultActivitiesActivity.class);
                startActivity(intentRent);
                finish();
            }
        });

        btnBookaVehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentBook = new Intent(AdultMainMenuActivity.this, AdultActivitiesActivity.class);
                startActivity(intentBook);
                finish();
            }
        });

        btnDisplayMyRides.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentDisplayRides = new Intent(AdultMainMenuActivity.this, AdultActivitiesActivity.class);
                startActivity(intentDisplayRides);
                finish();
            }
        });

        btnReportBrokenVehicle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentReport = new Intent(AdultMainMenuActivity.this, AdultActivitiesActivity.class);
                startActivity(intentReport);
                finish();
            }
        });

        btnDisplayGiftCoupon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentDisplayGift = new Intent(AdultMainMenuActivity.this, AdultActivitiesActivity.class);
                startActivity(intentDisplayGift);
                finish();
            }
        });

        btnAdultActivities.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentAdultActivities = new Intent(AdultMainMenuActivity.this, AdultActivitiesActivity.class);
                startActivity(intentAdultActivities);
                finish();
            }
        });
    }
}
